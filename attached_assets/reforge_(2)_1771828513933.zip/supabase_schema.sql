
-- 1. Create Profiles Table (Safe if exists)
create table if not exists public.profiles (
  id uuid not null references auth.users on delete cascade,
  email text,
  username text,
  name text,
  keys integer default 0,
  raw_data jsonb default '{}'::jsonb, -- Legacy blob storage (Transitioning out)
  level integer default 1,
  current_xp integer default 0,
  gold integer default 0,
  updated_at timestamp with time zone default timezone('utc'::text, now()),
  primary key (id)
);

-- 1.5 Explicitly add columns if they don't exist (Migration safety)
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS email text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS username text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS name text;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS level integer default 1;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS current_xp integer default 0;
ALTER TABLE public.profiles ADD COLUMN IF NOT EXISTS gold integer default 0;

-- 2. Enable Row Level Security (RLS)
alter table public.profiles enable row level security;

-- 3. DROP OLD POLICIES to avoid conflicts
drop policy if exists "Public profiles are viewable by everyone." on public.profiles;
drop policy if exists "Users can insert their own profile." on public.profiles;
drop policy if exists "Users can update own profile." on public.profiles;

-- 4. Re-create Profile Policies
create policy "Public profiles are viewable by everyone."
  on public.profiles for select
  using ( true );

create policy "Users can insert their own profile."
  on public.profiles for insert
  with check ( auth.uid() = id );

create policy "Users can update own profile."
  on public.profiles for update
  using ( auth.uid() = id );

-- ==========================================
-- NEW RELATIONAL TABLES (DATA PERSISTENCE)
-- ==========================================

-- 5. QUESTS TABLE
create table if not exists public.quests (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  title text not null,
  description text,
  rank text, -- 'E', 'D', 'C', 'B', 'A', 'S'
  priority text default 'MEDIUM',
  category text, -- 'strength', 'intelligence', etc.
  xp_reward integer default 0,
  is_completed boolean default false,
  is_daily boolean default false,
  failed boolean default false,
  created_at bigint, -- JS Timestamp
  expires_at bigint, -- JS Timestamp
  completed_at bigint, -- JS Timestamp
  ai_reasoning text
);
alter table public.quests enable row level security;

-- Quests Policies
create policy "Users can view own quests" on public.quests for select using (auth.uid() = user_id);
create policy "Users can insert own quests" on public.quests for insert with check (auth.uid() = user_id);
create policy "Users can update own quests" on public.quests for update using (auth.uid() = user_id);
create policy "Users can delete own quests" on public.quests for delete using (auth.uid() = user_id);


-- 6. INVENTORY TABLE (Outfits, Shadows, Items)
create table if not exists public.inventory (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  item_id text not null, -- Code ID (e.g. 'outfit_monarch')
  type text not null, -- 'OUTFIT', 'SHADOW', 'CONSUMABLE'
  is_equipped boolean default false,
  acquired_at timestamp with time zone default now(),
  constraint unique_item_per_user unique (user_id, item_id)
);
alter table public.inventory enable row level security;

-- Inventory Policies
create policy "Users can view own inventory" on public.inventory for select using (auth.uid() = user_id);
create policy "Users can insert own inventory" on public.inventory for insert with check (auth.uid() = user_id);
create policy "Users can update own inventory" on public.inventory for update using (auth.uid() = user_id);
create policy "Users can delete own inventory" on public.inventory for delete using (auth.uid() = user_id);


-- 7. ACTIVITY LOGS (Audit Trail)
create table if not exists public.activity_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  type text not null, -- 'XP', 'LEVEL_UP', 'PENALTY', 'PURCHASE'
  message text not null,
  timestamp bigint not null
);
alter table public.activity_logs enable row level security;

-- Activity Log Policies
create policy "Users can view own logs" on public.activity_logs for select using (auth.uid() = user_id);
create policy "Users can insert own logs" on public.activity_logs for insert with check (auth.uid() = user_id);


-- 8. WORKOUT LOGS (History)
create table if not exists public.workout_logs (
  id uuid default gen_random_uuid() primary key,
  user_id uuid references public.profiles(id) on delete cascade not null,
  workout_name text,
  exercises_completed integer,
  total_exercises integer,
  results jsonb, -- Store set details/reps as JSON
  xp_earned integer,
  timestamp bigint not null
);
alter table public.workout_logs enable row level security;

-- Workout Log Policies
create policy "Users can view own workouts" on public.workout_logs for select using (auth.uid() = user_id);
create policy "Users can insert own workouts" on public.workout_logs for insert with check (auth.uid() = user_id);


-- 9. USER TRIGGER (Auto-create profile)
create or replace function public.handle_new_user()
returns trigger
language plpgsql
security definer set search_path = public
as $$
begin
  insert into public.profiles (id, email, username, name, raw_data)
  values (
    new.id,
    new.email,
    coalesce(new.raw_user_meta_data ->> 'username', split_part(new.email, '@', 1)), 
    coalesce(new.raw_user_meta_data ->> 'full_name', 'Hunter'), 
    '{}'::jsonb
  )
  on conflict (id) do update set
    email = excluded.email;
  return new;
end;
$$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure public.handle_new_user();
